======
Models
======
Courier
-------
Courier delivers the packages.
States of couriers:

- idle
- standing by
- pending
- shipping

**State digram**:

.. image:: https://github.com/lepilepi/eturtle/raw/master/doc/img/StateChart.png

`<https://www.lucidchart.com/documents/edit#4eb6a07c-a910-47b4-902e-63ee0a7ce9c4?page=0&branch=231d6076-edc7-4175-b329-fd61e864b337>`_
